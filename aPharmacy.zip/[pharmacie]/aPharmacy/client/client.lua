ESX = nil


		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


local Pharmacie = false


------------------------------MENU SHOPS

local achat = RageUI.CreateMenu("Pharmacie", "Bienvenue", 10 , 80)
achat.Closed = function() Pharmacie = false end

function pharmacie()
    if Pharmacie then
        Pharmacie = false
    else
        Pharmacie = true
    RageUI.Visible(achat, true)
        CreateThread(function()
            while Pharmacie do
                Wait(1)
                RageUI.IsVisible(achat, function()

                    RageUI.Separator('~g~↓~s~ Nos Produits ~g~↓~s~')   --Séparateur 
                    
                    RageUI.Button("Bandage(s)", nil, {RightLabel = "~g~50$"}, true , {
                        onSelected = function()
                            TriggerServerEvent('atomh_:bandage')
                            Wait(1)
                        end
                    })

                    RageUI.Button("Kit(s) de Soin", nil, {RightLabel = "~g~100$"}, true , {
                        onSelected = function()
                            TriggerServerEvent('atomh_:kits')
                            Wait(1)	
                        end
                    })

                end)
            end
        end)
    end 
end 

------------------------------DRAWMARKERS


Citizen.CreateThread(function()
    while true do
        local pCoords2 = GetEntityCoords(PlayerPedId())
        local activerfps = false
        local dst = GetDistanceBetweenCoords(pCoords2, true)
        for _,v in pairs(Config.pharmacieposmenu) do
            if #(pCoords2 - v.position) < 1.5 then
                activerfps = true
                Visual.Subtitle("Appuyer sur ~g~[E]~s~ pour parler au pharmacien !")
            if Pharmacie == false then
                if IsControlJustReleased(0, 38) then
                    pharmacie()
                end
            end
            elseif #(pCoords2 - v.position) < 7.0 then
                activerfps = true
                DrawMarker(2, v.position, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.5, 0.5, 0.5, 23, 255, 0, 100, 1, 1, 2, 0, nil, nil, 0)
            end
        end
        if activerfps then
            Wait(1)
        else
            Wait(1500)
        end
    end
end)

------------------------------BLIPS

Citizen.CreateThread(function()

for _, info in pairs(Config.blipspharmacie) do
  info.blip = AddBlipForCoord(info.x, info.y, info.z)
  SetBlipSprite(info.blip, info.id)
  SetBlipDisplay(info.blip, 4)
  SetBlipScale(info.blip, 0.7)
  SetBlipColour(info.blip, info.colour)
  SetBlipAsShortRange(info.blip, true)
  BeginTextCommandSetBlipName("STRING")
  AddTextComponentString(info.title)
  EndTextCommandSetBlipName(info.blip)
    end
end)


Citizen.CreateThread(function()
    local hash = GetHashKey("s_m_m_doctor_01")
    while not HasModelLoaded(hash) do
    RequestModel(hash)
    Wait(20)
    end
    ped = CreatePed("PED_TYPE_CIVFEMALE", "s_m_m_doctor_01", -177.5864, 6384.435, 30.49539, 228.7077, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    FreezeEntityPosition(ped, true)
    end)






-- NE PAS ENLEVER !--
    print('')
    print('^3Crédits :')
    print('^2Créateur : atomh_ (атомh_#9373)')
    print('^6Serveur de développement A COMMUNITY DEV : https://discord.gg/N4UJW6WvWX')
    print('')
    