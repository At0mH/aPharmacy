Config = {} 


-------------------------LOC

Config.pharmacieposmenu = {
    {position = vector3(-176.8217, 6383.445, 31.49548)}
}

Config.blipspharmacie = {
    {title="[ ~g~MEDICAL~s~ ] Pharmacie", colour=2, id=51, x = -176.8217, y = 6383.445, z = 31.49548}
}
