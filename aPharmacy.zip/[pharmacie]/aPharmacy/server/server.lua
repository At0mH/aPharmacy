ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterNetEvent('atomh_:bandage')
AddEventHandler('atomh_:bandage', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    local price = 50
    local xMoney = xPlayer.getMoney()

    if xMoney >= price then

    xPlayer.removeMoney(price)
    xPlayer.addInventoryItem('bandage', 1)
	TriggerClientEvent('esx:showAdvancedNotification', source, 'Banque', '', 'Un payement à été aprouvé par votre banque.                       ~g~~h~Montant~s~ : 50$', 'CHAR_BANK_FLEECA', 8)
    else
        TriggerClientEvent('esx:showAdvancedNotification', source, 'Banque', '', 'Un payement à été refusé par votre banque.                       ~r~~h~Raison~s~ : Votre solde n\'est pas assez elevé pour votre achat', 'CHAR_BANK_FLEECA', 8)
    end
end)

RegisterNetEvent('atomh_:kits')
AddEventHandler('atomh_:kits', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    local price = 100
    local xMoney = xPlayer.getMoney()

    if xMoney >= price then

    xPlayer.removeMoney(price)
    xPlayer.addInventoryItem('medikit', 1)
	TriggerClientEvent('esx:showAdvancedNotification', source, 'Banque', '', 'Un payement à été aprouvé par votre banque.                       ~g~~h~Montant~s~ : 100$', 'CHAR_BANK_FLEECA', 8)
    else
        TriggerClientEvent('esx:showAdvancedNotification', source, 'Banque', '', "Un payement à été refusé par votre banque.                       ~r~~h~Raison~s~ : Votre solde n'est pas assez elevé pour votre achat", 'CHAR_BANK_FLEECA', 8)
    end
end)



